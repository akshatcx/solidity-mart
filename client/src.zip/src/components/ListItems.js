import React from 'react';
import {
  Tabs,
  Tab,
  Navbar,
  Nav,
  Container,
  FormControl,
  FormGroup,
  Form,
  Button,
  Table,
  AccordionButton,
} from "react-bootstrap";
import {
  ContractForm,
  ContractData
} from "@drizzle/react-components"

/**
 * 
 */
class ListItems extends React.Component {
  constructor(props) {
    super(props)
    // this.handleChange = this.handleChange.bind(this)
    // this.handleSubmit = this.handleSubmit.bind(this)
  }

  componentDidMount() {
    const {
      drizzle
    } = this.props;
  }

  render() {
    return ( <
      ContractData contract ="SolidityMart"
        method="listItems"
        render={
          (inp) => {
            // console.log(inp)
            return (
            <Container>
              <Table>
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Price</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                  {
                    inp.map((row, index) => {
                    console.log(row)
                    return (
                      <tr>
                      <td>{row[1]}</td>
                      <td>{row[2]}</td>
                      <td>{row[3]}</td>
                      <td>
                        <Accordion eventKey="0">Buy</Accordion>
                      </td>
                      </tr>
                    )
                  })
                  }
                </tbody>
            </Table>
            </Container>
            )
          }
        }
      />
    );
  }
}
export default ListItems;